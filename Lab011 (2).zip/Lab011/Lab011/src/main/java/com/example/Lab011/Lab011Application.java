package com.example.Lab011;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class Lab011Application {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		SpringApplication.run(Lab011Application.class, args);
		ApplicationContext ac = new ClassPathXmlApplicationContext("testBean.xml");
		Customer c = (Customer)ac.getBean("customer");
		Ticket t = (Ticket)c.getTick();
		while(true) {
			System.out.println("1.Insert\n 2.Display\n" +"3.exit");
			System.out.println("Enter choice");
			int ch = sc.nextInt();
			switch(ch) {
			case 1:
				System.out.println("Insert Details");
				System.out.println("Enter customer name");
				c.setName(sc.next());
				System.out.println("Enter customer address");
				c.setAddress(sc.next());
				System.out.println("Enter Ticket Number");
				t.setTicno(sc.nextInt());
				System.out.println("Enter Seat Number");
				t.setSeatNo(sc.nextInt());
				System.out.println("Enter the price");
				t.setPrice(sc.nextInt());
				System.out.println("Enter the Ticktype");
				t.setTickType(sc.next());
				c.setTick(t);
				break;
			case 2:
				System.out.println("Customer Details");
				System.out.println("Name" + c.getName()+" "+"Address" + c.getAddress());
				
				System.out.println("Ticket Details");
				t = c.getTick();
				System.out.println("Tic no" + t.getTicno());
				System.out.println("Seat no" + t.getSeatNo());
				System.out.println("price" + t.getPrice());
				System.out.println("Tick type" + t.getTickType());
				break;
				
			}
		}
	}

}
