package com.example.Lab011;

public class Ticket {
	int Ticno,seatNo,Price;
	String tickType;
	public int getTicno() {
		return Ticno;
	}
	public void setTicno(int ticno) {
		Ticno = ticno;
	}
	public int getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		Price = price;
	}
	public String getTickType() {
		return tickType;
	}
	public void setTickType(String tickType) {
		this.tickType = tickType;
	}
	
	

}
