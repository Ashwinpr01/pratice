package com.example.Lab011;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab011ApplicationTests {

	@Test
	void contextLoads() {
	}

}
