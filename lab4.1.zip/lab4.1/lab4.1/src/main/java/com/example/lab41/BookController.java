package com.example.lab41;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/books")
public class BookController {
	private final List<Book>books = new ArrayList<Book>();
	
	@GetMapping
	public List<Book> getAllBooks(){
		return books;
	}
	@GetMapping("/{id}")
		public Book getBookById(@PathVariable long id) {
			return findBookById(id);
		}
	
	@PostMapping
	public Book addBook(@RequestBody Book book) {
		book.setId(generatedBookId());
		books.add(book);
		return book;
	}
	
	@PutMapping("/{id}")
	public Book updateBook(@PathVariable long id,@RequestBody Book updatedbook) {
		Book eb= findBookById(id);
		
		if(eb != null) {
			eb.setAuthor(updatedbook.getAuthor());
			eb.setTitle(updatedbook.getTitle());
			eb.setPub_year(updatedbook.getPub_year());
		}
		return eb;
	}
	
	@DeleteMapping("/{id}")
	public void deleteBook(@PathVariable long id) {
		Book booksToRemove =findBookById(id);
		if(booksToRemove != null) {
			books.remove(booksToRemove);
		}
	}
	
	private Book findBookById(Long id) {
		for(Book book:books) {
			if(book.getId().equals(id)) {
				return book;
			}
		}
		return null;
	}
	
	private long generatedBookId() {
		return System.currentTimeMillis();
	}
	
	

}
