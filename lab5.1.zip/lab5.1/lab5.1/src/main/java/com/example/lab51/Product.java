package com.example.lab51;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class Product {
	@Min(1)
	@Max(100)
	@NotNull(message="id is required")
	private long id;
	
	@NotBlank(message="name is required")
	private String name;
	
	@Min(1)
	@NotNull(message="price is requried")
	private double price;

}
