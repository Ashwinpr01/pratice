package lab6;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class student_main {
	SessionFactory sc=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	Session session=sc.openSession();
	Transaction t=session.beginTransaction();
	public void insert(int id,String address,String name,String usn,int totalmarks) {
		student s=new student();
		s.setId(id);
		s.setAddress(address);
		s.setName(name);
		s.setUsn(usn);
		s.setTotalmarks(totalmarks);
		session.save(s);
		t.commit();
	}
	
	public void delete(String usn) {
		Query q=session.createQuery("from the table student");
		q.setParameter("usn",usn);
		int status=q.executeUpdate();
		if(status==0) {
			System.out.println(usn+"deleted");
		}else 
		{
			System.out.println(usn+"not found");
		}
		
	}
	public void display() {
		Query q=session.createQuery("from student");
		List l=q.getResultList();
		Iterator it=l.iterator();
		System.out.println("student List");
		while(it.hasNext()) {
			student s=(student)it.next();
			System.out.println(s.toString());
		}
	}
	public void search(String usn) {
		Query q=session.createQuery("from the student");
		q.setParameter("usn",usn);
		List l=q.getResultList();
		if(l.isEmpty()) {
			System.out.println("not found");
		}
		else {
			Iterator it=l.iterator();
			System.out.println("student list");
			while(it.hasNext()) {
				student s=(student)it.next();
				System.out.println(s.toString());
			}
		}
	}
	public static void main(String[] args) {
		student_main sm=new student_main();
		Scanner sc=new Scanner(System.in);
		
		while(true) {
			System.out.println("Student deatils");
			System.out.println("1.insert");
			System.out.println("2.display");
			System.out.println("3.search");
			System.out.println("4.delete");
			System.out.println("5.exit");
			System.out.println("enter your choice");
			int a=sc.nextInt();
			switch(a) {
			case 1:
				System.out.println("enter the student id");
				int id=sc.nextInt();
				System.out.println("enter the name");
				String name=sc.next();
				System.out.println("enter the address");
				String address=sc.next();
				System.out.println("enter the usn");
				String usn=sc.next();
				System.out.println("enter the total marks");
				int totalmarks=sc.nextInt();
				sm.insert(id, address, name, usn, totalmarks);
				break;
				
			case 2:
				sm.display();
				break;
			case 3:
				System.out.println("enter the usn to search");
				String usn1=sc.next();
				sm.search(usn1);
				
			case 4:
				System.out.println("enter the usn to delete");
				String usn2=sc.next();
				sm.delete(usn2);
				break;
			case 5:
				break;
				
			}
			
		}
		
	}
	
	

}
