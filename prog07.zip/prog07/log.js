localStorage.setItem("username","rvce");
localStorage.setItem("passme","rvce");

function verify(){
    let username=document.getElementById("username").value;
    let password= document.getElementById("password").value;
    let un=localStorage.getItem("username");
    let up=localStorage.getItem("passme");
    alert(username+""+password+""+un+""+up);

    let sun=un.localeCompare(username);
    let sup=up.localeCompare(password);

    if(sun != -1 && sup != -1){
        alert("done");
    }else{
        alert("not");
    }
}