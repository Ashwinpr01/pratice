self.addEventListener('install',(e)=>{
    console.log("install");
})
self.addEventListener('activate',(e)=>{
    console.log("activate");
})
self.addEventListener('fetch',(e)=>{
    console.log("fetched");

    fetch("https://api.github/users")
    .then((response)=>{
        return response.json();
    })

    .then((json)=>{
        console.log(json);
    })

    .catch((error)=>{
        console.log(error);
    })
});